<!-- Sidebar -->
<div class="sidebar" id="sidebar">
    <div class="sidebar-inner slimscroll">
        <div id="sidebar-menu" class="sidebar-menu">
            <ul>


                <li class="submenu">
                    <a href="#"><i class="la la-pie-chart"></i> <span> Products </span> <span class="menu-arrow"></span></a>
                    <ul>
                        <li><a href="{{url('/products')}}">Add Product </a></li>
                        <li><a href="{{url('/products')}}">Products List </a></li>

                    </ul>
                </li>


                <li class="submenu">
                    <a href="#"><i class="la la-pie-chart"></i> <span> Orders </span> <span class="menu-arrow"></span></a>
                    <ul>

                        <li><a href="{{url('/orders-list')}}">Orders List </a></li>

                    </ul>
                </li>




            </ul>
        </div>
    </div>
</div>
<!-- /Sidebar -->
